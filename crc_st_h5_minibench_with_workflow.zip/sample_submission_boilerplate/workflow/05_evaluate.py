#!/usr/bin/env python3
import json
from pathlib import Path
import pandas as pd

root = Path(__file__).resolve().parents[1]

# Inputs
metrics_tsv = root/"results"/"metrics"/"spot_metrics.tsv"
topgenes_txt = root/"results"/"metrics"/"top_genes.txt"
marker_scores_tsv = root/"results"/"markers"/"marker_scores.tsv"
cms_markers_tsv = root/"workflow"/"markers_crc_cms.tsv"

# --- q1–q3 from metrics ---
dfm = pd.read_csv(metrics_tsv, sep="\t")
dfm = dfm.set_index("metric")["value"]

q1 = int(dfm["spots_total"])
q2 = int(dfm["spots_nonzero"])

# Allow either key naming
median_genes_key = "median_genes_per_spot" if "median_genes_per_spot" in dfm.index else "median_genes"
q3 = int(round(float(dfm[median_genes_key])))

# --- q4 top 5 genes ---
top5 = [g.strip() for g in topgenes_txt.read_text().strip().splitlines() if g.strip()]
top5 = top5[:5]

# --- q5 CMS call ---
# Load per-gene totals
mk = pd.read_csv(marker_scores_tsv, sep="\t")
mk = mk.rename(columns={c:c.lower() for c in mk.columns})
assert {"gene","score"}.issubset(mk.columns), "marker_scores.tsv must have 'gene' and 'score' columns"

# Load CMS marker mapping (auto-sep sniff)
cms = pd.read_csv(cms_markers_tsv, sep=None, engine="python")
cms = cms.rename(columns={c:c.lower() for c in cms.columns})
# Be flexible about column names
if not {"gene","cms"}.issubset(cms.columns):
    # try first two columns as gene/cms
    cms = cms.rename(columns={cms.columns[0]:"gene", cms.columns[1]:"cms"})
cms["gene"] = cms["gene"].astype(str)

# Join and aggregate scores per CMS
joined = mk.merge(cms[["gene","cms"]], on="gene", how="inner")
cms_scores = joined.groupby("cms")["score"].sum().sort_values(ascending=False)
cms_label = str(cms_scores.index[0]) if len(cms_scores) else "CMS2"  # safe default if nothing matches
q5 = f"{cms_label}_like"

# --- write results.json ---
out_json = root/"results"/"results.json"
out_json.write_text(json.dumps({"q1": q1, "q2": q2, "q3": q3, "q4": top5, "q5": q5}, indent=2))
print(f"[ok] wrote {out_json}")
